﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Build.Construction;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using WebNavigation.Data;
using WebNavigation.Models;

namespace WebNavigation.Controllers
{
    public class EtudiantsController : Controller
    {
        private readonly WebNavigationContext _context;

        public EtudiantsController(WebNavigationContext context)
        {
            _context = context;
        }

        // GET: Etudiants
        public async Task<IActionResult> Index(string? paramRech,int? paramGr,string? sortOrder="NAsc")
        {
            Groupe g = new Groupe() { Id = 0, LibGroupe = "Toutes" };
            List<Groupe> resGroupes = _context.Groupe.ToList();
            resGroupes.Insert(0,g);
            ViewData["gr"] = new SelectList(resGroupes, "Id", "LibGroupe",paramGr);
            if (paramRech == null)
            {
                paramRech = "";
            }
            ViewBag.Rech = paramRech;
            var res = _context.Etudiant.Include(e => e.Groupe)
                .Where(x => x.Nom.Contains(paramRech)||x.Prenom.Contains(paramRech));
            if(paramGr != null&&paramGr !=0)
            {
                res = res.Where(x => x.GroupeId == paramGr);
            }
            ViewBag.tNom = sortOrder == "NAsc" ? "NDesc" : "NAsc";
            ViewBag.tPrenom = sortOrder == "NAsc" ? "NDesc" : "PAsc";

            switch (sortOrder)
            {
                case "NAsc":
                    res = res.OrderBy(s => s.Nom);
                    break;
                case "NDesc":
                    res = res.OrderByDescending(s => s.Nom);
                    break;
                case "PAsc":
                    res = res.OrderBy(s => s.Prenom);
                    break;
                case "PDesc":
                    res = res.OrderByDescending(s => s.Prenom);
                    break;
            }

          /* if (sortNom=="asc")
            {
                res = res.OrderBy(x => x.Nom);
                ViewBag.tNom = "desc";
            }
            else
            {
               res =  res.OrderByDescending(x => x.Nom);
            }*/
           
              
            return View(await res.ToListAsync());
        }

        // GET: Etudiants/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Etudiant == null)
            {
                return NotFound();
            }

            var etudiant = await _context.Etudiant
                .Include(e => e.Groupe)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (etudiant == null)
            {
                return NotFound();
            }

            return View(etudiant);
        }

        // GET: Etudiants/Create
        public IActionResult Create()
        {
            ViewData["GroupeId"] = new SelectList(_context.Groupe, "Id", "LibGroupe");
            return View();
        }

        // POST: Etudiants/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Nom,Prenom,DateN,GroupeId")] Etudiant etudiant)
        {
            if (ModelState.IsValid)
            {
                _context.Add(etudiant);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["GroupeId"] = new SelectList(_context.Groupe, "Id", "LibGroupe", etudiant.GroupeId);
            return View(etudiant);
        }

        // GET: Etudiants/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Etudiant == null)
            {
                return NotFound();
            }

            var etudiant = await _context.Etudiant.FindAsync(id);
            if (etudiant == null)
            {
                return NotFound();
            }
            ViewData["GroupeId"] = new SelectList(_context.Groupe, "Id", "LibGroupe", etudiant.GroupeId);
            return View(etudiant);
        }

        // POST: Etudiants/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Nom,Prenom,DateN,GroupeId")] Etudiant etudiant)
        {
            if (id != etudiant.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(etudiant);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EtudiantExists(etudiant.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["GroupeId"] = new SelectList(_context.Groupe, "Id", "LibGroupe", etudiant.GroupeId);
            return View(etudiant);
        }

        // GET: Etudiants/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Etudiant == null)
            {
                return NotFound();
            }

            var etudiant = await _context.Etudiant
                .Include(e => e.Groupe)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (etudiant == null)
            {
                return NotFound();
            }

            return View(etudiant);
        }

        // POST: Etudiants/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Etudiant == null)
            {
                return Problem("Entity set 'WebNavigationContext.Etudiant'  is null.");
            }
            var etudiant = await _context.Etudiant.FindAsync(id);
            if (etudiant != null)
            {
                _context.Etudiant.Remove(etudiant);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool EtudiantExists(int id)
        {
          return (_context.Etudiant?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
